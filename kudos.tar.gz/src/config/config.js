const GLOBAL_VARIABLES = window.appticles.config;

export default GLOBAL_VARIABLES;
